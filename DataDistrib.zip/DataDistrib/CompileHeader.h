Define C$_CompileDateTime for "2023-04-15 10:21:17,726"
