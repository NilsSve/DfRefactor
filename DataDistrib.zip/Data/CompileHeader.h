Define C$_CompileDateTime for "2023-05-24 14:38:07,432"
