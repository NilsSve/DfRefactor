Define C$_CompileDateTime for "2023-11-06 17:32:50,086"
